USE [FoodDB]
GO

/****** Object:  Table [dbo].[AdminLogin]    Script Date: 3/25/2024 9:16:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AdminLogin](
	[Email] [varchar](25) NULL,
	[Password] [varchar](10) NULL
) ON [PRIMARY]
GO


