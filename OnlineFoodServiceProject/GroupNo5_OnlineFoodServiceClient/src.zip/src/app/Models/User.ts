export class User{
    userId: number;
    userName: string;
    email: string;
    password: string;
    phoneNo: string;
    address: string;
    postCode: string;
    role:string;
}