export class cart{

     cartId:number;
     mImage : string;
     menuName :string;
     price : number;
     quantity : number=1;
}