export class Order{

     menuName :string;
   price :number;
   quantity :number;
   totalPrice : number;
}