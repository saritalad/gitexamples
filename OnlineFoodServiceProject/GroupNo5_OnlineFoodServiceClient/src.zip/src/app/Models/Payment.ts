export class Payment{
     
fullName :string;
 email :string;
 address :string;
 city :string;
 state:string;
 zipCode :string;
 nameOnCard :string;
 creditCardNumber :string;
 expMonth :string;
 expYear :string;
 cvv :number;
}