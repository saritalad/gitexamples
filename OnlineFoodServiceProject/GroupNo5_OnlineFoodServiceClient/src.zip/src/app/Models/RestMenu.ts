export class RestMenu{
     menuItemId : number ;
     restaurantId : number ;
     rName :  string ;
     menuName :  string ;
     price : number ;
}