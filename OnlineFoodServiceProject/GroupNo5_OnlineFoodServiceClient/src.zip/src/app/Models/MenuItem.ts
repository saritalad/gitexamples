export class MenuItem{

     menuItemId : number;
     restaurantId :number ;
     menuName :  string ;
     price : number;
     mImage :  string;
}