export class Receipt{
           cartId :number;
           fullName :string;  
           email :string;  
           address : string; 
           city  : string;  
           state : string;   
           zipCode   : string; 
           menuName   : string; 
        price   : number; 
        quantity : number;   
}