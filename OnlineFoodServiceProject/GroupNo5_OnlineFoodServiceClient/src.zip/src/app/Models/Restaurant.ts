export class Restaurant{
    restaurantId:number;
    rName:string;
    location:string;
    image:string;
    
    }