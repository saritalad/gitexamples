import { Component } from '@angular/core';
import { User } from '../Models/User';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent {
  adminobj:{
    name:"";

  }

}
